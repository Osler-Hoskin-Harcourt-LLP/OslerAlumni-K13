SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_MultiBuyDiscountCollection](
	[MultibuyDiscountID] [int] NOT NULL,
	[CollectionID] [int] NOT NULL,
	[CollectionIncluded] [bit] NOT NULL,
 CONSTRAINT [PK_COM_MultiBuyDiscountCollection] PRIMARY KEY CLUSTERED 
(
	[MultibuyDiscountID] ASC,
	[CollectionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscountCollection_CollectionID] ON [dbo].[COM_MultiBuyDiscountCollection]
(
	[CollectionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountCollection] ADD  CONSTRAINT [DEFAULT_COM_MultiBuyDiscountCollection_CollectionID]  DEFAULT ((0)) FOR [CollectionID]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountCollection] ADD  CONSTRAINT [DEFAULT_COM_MultiBuyDiscountCollection_CollectionIncluded]  DEFAULT ((1)) FOR [CollectionIncluded]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountCollection]  WITH CHECK ADD  CONSTRAINT [FK_COM_MultiBuyDiscountCollection_CollectionID_COM_Collection] FOREIGN KEY([CollectionID])
REFERENCES [dbo].[COM_Collection] ([CollectionID])
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountCollection] CHECK CONSTRAINT [FK_COM_MultiBuyDiscountCollection_CollectionID_COM_Collection]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountCollection]  WITH CHECK ADD  CONSTRAINT [FK_COM_MultiBuyDiscountCollection_MultiBuyDiscountID_COM_MultiBuyDiscount] FOREIGN KEY([MultibuyDiscountID])
REFERENCES [dbo].[COM_MultiBuyDiscount] ([MultiBuyDiscountID])
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountCollection] CHECK CONSTRAINT [FK_COM_MultiBuyDiscountCollection_MultiBuyDiscountID_COM_MultiBuyDiscount]
GO
