SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Newsletter_Unsubscription](
	[UnsubscriptionID] [int] IDENTITY(1,1) NOT NULL,
	[UnsubscriptionEmail] [nvarchar](254) NOT NULL,
	[UnsubscriptionCreated] [datetime2](7) NOT NULL,
	[UnsubscriptionNewsletterID] [int] NULL,
	[UnsubscriptionFromIssueID] [int] NULL,
	[UnsubscriptionGUID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Newsletter_Unsubscription] PRIMARY KEY CLUSTERED 
(
	[UnsubscriptionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_Unsubscription_Email_NewsletterID] ON [dbo].[Newsletter_Unsubscription]
(
	[UnsubscriptionEmail] ASC,
	[UnsubscriptionNewsletterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_Unsubscription_NewsletterID] ON [dbo].[Newsletter_Unsubscription]
(
	[UnsubscriptionNewsletterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_Newsletter_Unsubscription_UnsubscriptionFromIssueID] ON [dbo].[Newsletter_Unsubscription]
(
	[UnsubscriptionFromIssueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Newsletter_Unsubscription] ADD  CONSTRAINT [DEFAULT_Newsletter_Unsubscription_UnsubscriptionEmail]  DEFAULT (N'') FOR [UnsubscriptionEmail]
GO
ALTER TABLE [dbo].[Newsletter_Unsubscription]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_Unsubscription_UnsubscriptionFromIssueID_Newsletter_NewsletterIssue] FOREIGN KEY([UnsubscriptionFromIssueID])
REFERENCES [dbo].[Newsletter_NewsletterIssue] ([IssueID])
GO
ALTER TABLE [dbo].[Newsletter_Unsubscription] CHECK CONSTRAINT [FK_Newsletter_Unsubscription_UnsubscriptionFromIssueID_Newsletter_NewsletterIssue]
GO
ALTER TABLE [dbo].[Newsletter_Unsubscription]  WITH CHECK ADD  CONSTRAINT [FK_Newsletter_Unsubscription_UnsubscriptionNewsletterID_Newsletter_Newsletter] FOREIGN KEY([UnsubscriptionNewsletterID])
REFERENCES [dbo].[Newsletter_Newsletter] ([NewsletterID])
GO
ALTER TABLE [dbo].[Newsletter_Unsubscription] CHECK CONSTRAINT [FK_Newsletter_Unsubscription_UnsubscriptionNewsletterID_Newsletter_Newsletter]
GO
