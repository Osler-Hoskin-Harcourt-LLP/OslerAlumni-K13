CREATE TYPE [dbo].[Type_OM_ActivityTable] AS TABLE(
	[ActivityID] [int] NOT NULL,
	[ActivityContactID] [int] NOT NULL,
	[ActivityCreated] [datetime2](7) NULL,
	[ActivityType] [nvarchar](250) NOT NULL,
	[ActivityItemID] [int] NULL,
	[ActivityItemDetailID] [int] NULL,
	[ActivityValue] [nvarchar](250) NULL,
	[ActivityURL] [nvarchar](max) NULL,
	[ActivityTitle] [nvarchar](250) NULL,
	[ActivitySiteID] [int] NOT NULL,
	[ActivityComment] [nvarchar](max) NULL,
	[ActivityCampaign] [nvarchar](200) NULL,
	[ActivityURLReferrer] [nvarchar](max) NULL,
	[ActivityCulture] [nvarchar](10) NULL,
	[ActivityNodeID] [int] NULL,
	[ActivityUTMSource] [nvarchar](200) NULL,
	[ActivityABVariantName] [nvarchar](200) NULL,
	[ActivityURLHash] [bigint] NOT NULL,
	[ActivityUTMContent] [nvarchar](200) NULL
)
GO
