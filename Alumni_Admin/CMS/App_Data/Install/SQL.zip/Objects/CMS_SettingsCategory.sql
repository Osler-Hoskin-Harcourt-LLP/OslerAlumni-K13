SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_SettingsCategory](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryDisplayName] [nvarchar](200) NOT NULL,
	[CategoryOrder] [int] NULL,
	[CategoryName] [nvarchar](100) NULL,
	[CategoryParentID] [int] NULL,
	[CategoryIDPath] [nvarchar](450) NULL,
	[CategoryLevel] [int] NULL,
	[CategoryChildCount] [int] NULL,
	[CategoryIconPath] [nvarchar](200) NULL,
	[CategoryIsGroup] [bit] NULL,
	[CategoryIsCustom] [bit] NULL,
	[CategoryResourceID] [int] NULL,
 CONSTRAINT [PK_CMS_SettingsCategory] PRIMARY KEY NONCLUSTERED 
(
	[CategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE CLUSTERED INDEX [IX_CMS_SettingsCategory_CategoryOrder] ON [dbo].[CMS_SettingsCategory]
(
	[CategoryOrder] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_SettingsCategory_CategoryParentID] ON [dbo].[CMS_SettingsCategory]
(
	[CategoryParentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_SettingsCategory_CategoryResourceID] ON [dbo].[CMS_SettingsCategory]
(
	[CategoryResourceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_SettingsCategory] ADD  CONSTRAINT [DEFAULT_CMS_SettingsCategory_CategoryDisplayName]  DEFAULT ('') FOR [CategoryDisplayName]
GO
ALTER TABLE [dbo].[CMS_SettingsCategory] ADD  CONSTRAINT [DEFAULT_CMS_SettingsCategory_CategoryIsGroup]  DEFAULT ((0)) FOR [CategoryIsGroup]
GO
ALTER TABLE [dbo].[CMS_SettingsCategory] ADD  CONSTRAINT [DEFAULT_CMS_SettingsCategory_CategoryIsCustom]  DEFAULT ((0)) FOR [CategoryIsCustom]
GO
ALTER TABLE [dbo].[CMS_SettingsCategory]  WITH CHECK ADD  CONSTRAINT [FK_CMS_SettingsCategory_CategoryResourceID_CMS_Resource] FOREIGN KEY([CategoryResourceID])
REFERENCES [dbo].[CMS_Resource] ([ResourceID])
GO
ALTER TABLE [dbo].[CMS_SettingsCategory] CHECK CONSTRAINT [FK_CMS_SettingsCategory_CategoryResourceID_CMS_Resource]
GO
ALTER TABLE [dbo].[CMS_SettingsCategory]  WITH CHECK ADD  CONSTRAINT [FK_CMS_SettingsCategory_CMS_SettingsCategory1] FOREIGN KEY([CategoryParentID])
REFERENCES [dbo].[CMS_SettingsCategory] ([CategoryID])
GO
ALTER TABLE [dbo].[CMS_SettingsCategory] CHECK CONSTRAINT [FK_CMS_SettingsCategory_CMS_SettingsCategory1]
GO
ALTER TABLE [dbo].[CMS_SettingsCategory]  WITH CHECK ADD  CONSTRAINT [CK_CMS_SettingsCategory_CategoryLevel] CHECK  (([CategoryLevel]>=(0)))
GO
ALTER TABLE [dbo].[CMS_SettingsCategory] CHECK CONSTRAINT [CK_CMS_SettingsCategory_CategoryLevel]
GO
