SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ModuleUsageCounter](
	[ModuleUsageCounterID] [int] IDENTITY(1,1) NOT NULL,
	[ModuleUsageCounterName] [nvarchar](200) NOT NULL,
	[ModuleUsageCounterValue] [bigint] NOT NULL
)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE CLUSTERED INDEX [IX_CMS_ModuleUsageCounter_ModuleUsageCounterName] ON [dbo].[CMS_ModuleUsageCounter]
(
	[ModuleUsageCounterName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_ModuleUsageCounter] ADD  CONSTRAINT [DEFAULT_CMS_ModuleUsageCounter_ModuleUsageCounterName]  DEFAULT (N'') FOR [ModuleUsageCounterName]
GO
ALTER TABLE [dbo].[CMS_ModuleUsageCounter] ADD  CONSTRAINT [DEFAULT_CMS_ModuleUsageCounter_ModuleUsageCounterValue]  DEFAULT ((0)) FOR [ModuleUsageCounterValue]
GO
