SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_Email_DeleteArchived]
	@SiteID int,
	@ExpirationDate datetime2(7),
	@BatchSize int
AS
BEGIN
SET NOCOUNT ON;

-- Code for archived email status
DECLARE @Archived AS int = 3

-- Declare table for emails
CREATE TABLE #Emails (EmailID int NOT NULL, PRIMARY KEY(EmailID))

-- Get global e-mails
IF ((@SiteID = 0) OR (@SiteID IS NULL))
	INSERT INTO #Emails
        SELECT TOP(@BatchSize) EmailID FROM CMS_Email
			WHERE (EmailLastSendAttempt <= @ExpirationDate) AND (EmailSiteID IS NULL OR EmailSiteID = 0) AND (EmailStatus = @Archived)

-- Get all e-mails attached to the site
ELSE
	INSERT INTO #Emails
		SELECT TOP(@BatchSize) EmailID FROM CMS_Email
			WHERE (EmailLastSendAttempt <= @ExpirationDate) AND (EmailSiteID = @SiteID) AND (EmailStatus = @Archived)

-- Delete attachment binding
DELETE FROM [CMS_AttachmentForEmail] WHERE EmailID IN (SELECT EmailID FROM #Emails)

-- Delete user binding
DELETE FROM [CMS_EmailUser] WHERE EmailID IN (SELECT EmailID FROM #Emails)

-- Delete e-mails
DELETE FROM [CMS_Email] WHERE EmailID IN (SELECT EmailID FROM #Emails)

-- Return number of deleted emails
SELECT @@ROWCOUNT

DROP TABLE #Emails
END
GO
