SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_SearchTaskAzure](
	[SearchTaskAzureID] [int] IDENTITY(1,1) NOT NULL,
	[SearchTaskAzureType] [nvarchar](100) NOT NULL,
	[SearchTaskAzureObjectType] [nvarchar](100) NULL,
	[SearchTaskAzureMetadata] [nvarchar](200) NULL,
	[SearchTaskAzureAdditionalData] [nvarchar](600) NOT NULL,
	[SearchTaskAzureInitiatorObjectID] [int] NULL,
	[SearchTaskAzurePriority] [int] NOT NULL,
	[SearchTaskAzureErrorMessage] [nvarchar](max) NULL,
	[SearchTaskAzureCreated] [datetime2](7) NOT NULL,
	[SearchTaskAzureIndexerName] [nvarchar](100) NULL,
 CONSTRAINT [PK_CMS_SearchTaskAzure] PRIMARY KEY CLUSTERED 
(
	[SearchTaskAzureID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_SearchTaskAzure_SearchTaskAzurePriority] ON [dbo].[CMS_SearchTaskAzure]
(
	[SearchTaskAzurePriority] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_SearchTaskAzure] ADD  CONSTRAINT [DEFAULT_CMS_SearchTaskAzure_SearchTaskAzureType]  DEFAULT (N'') FOR [SearchTaskAzureType]
GO
ALTER TABLE [dbo].[CMS_SearchTaskAzure] ADD  CONSTRAINT [DEFAULT_CMS_SearchTaskAzure_SearchTaskAzureAdditionalData]  DEFAULT (N'') FOR [SearchTaskAzureAdditionalData]
GO
ALTER TABLE [dbo].[CMS_SearchTaskAzure] ADD  CONSTRAINT [DEFAULT_CMS_SearchTaskAzure_SearchTaskAzurePriority]  DEFAULT ((0)) FOR [SearchTaskAzurePriority]
GO
ALTER TABLE [dbo].[CMS_SearchTaskAzure] ADD  CONSTRAINT [DEFAULT_CMS_SearchTaskAzure_SearchTaskAzureCreated]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [SearchTaskAzureCreated]
GO
