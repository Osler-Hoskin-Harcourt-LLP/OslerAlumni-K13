CREATE TYPE [dbo].[Type_Analytics_LogHitsTable] AS TABLE(
	[SiteID] [int] NULL,
	[CodeName] [nvarchar](250) NOT NULL,
	[Culture] [nvarchar](10) NULL,
	[ObjectName] [nvarchar](450) NULL,
	[ObjectId] [int] NULL,
	[Hits] [int] NULL,
	[Value] [float] NULL,
	[HourStart] [datetime2](7) NOT NULL,
	[HourEnd] [datetime2](7) NOT NULL,
	[DayStart] [datetime2](7) NOT NULL,
	[DayEnd] [datetime2](7) NOT NULL,
	[WeekStart] [datetime2](7) NOT NULL,
	[WeekEnd] [datetime2](7) NOT NULL,
	[MonthStart] [datetime2](7) NOT NULL,
	[MonthEnd] [datetime2](7) NOT NULL,
	[YearStart] [datetime2](7) NOT NULL,
	[YearEnd] [datetime2](7) NOT NULL
)
GO
