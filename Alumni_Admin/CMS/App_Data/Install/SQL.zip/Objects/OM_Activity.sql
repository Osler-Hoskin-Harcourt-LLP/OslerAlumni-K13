SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_Activity](
	[ActivityID] [int] IDENTITY(1,1) NOT NULL,
	[ActivityContactID] [int] NOT NULL,
	[ActivityCreated] [datetime2](7) NULL,
	[ActivityType] [nvarchar](250) NOT NULL,
	[ActivityItemID] [int] NULL,
	[ActivityItemDetailID] [int] NULL,
	[ActivityValue] [nvarchar](250) NULL,
	[ActivityURL] [nvarchar](max) NULL,
	[ActivityTitle] [nvarchar](250) NULL,
	[ActivitySiteID] [int] NOT NULL,
	[ActivityComment] [nvarchar](max) NULL,
	[ActivityCampaign] [nvarchar](200) NULL,
	[ActivityURLReferrer] [nvarchar](max) NULL,
	[ActivityCulture] [nvarchar](50) NULL,
	[ActivityNodeID] [int] NULL,
	[ActivityUTMSource] [nvarchar](200) NULL,
	[ActivityABVariantName] [nvarchar](200) NULL,
	[ActivityURLHash] [bigint] NOT NULL,
	[ActivityUTMContent] [nvarchar](200) NULL,
 CONSTRAINT [PK_OM_Activity] PRIMARY KEY CLUSTERED 
(
	[ActivityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_OM_Activity_ActivityCampaign] ON [dbo].[OM_Activity]
(
	[ActivityCampaign] ASC
)
INCLUDE([ActivityContactID]) 
WHERE ([ActivityCampaign] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
GO
CREATE NONCLUSTERED INDEX [IX_OM_Activity_ActivityContactID] ON [dbo].[OM_Activity]
(
	[ActivityContactID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OM_Activity_ActivityCreated] ON [dbo].[OM_Activity]
(
	[ActivityCreated] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OM_Activity_ActivityItemDetailID] ON [dbo].[OM_Activity]
(
	[ActivityItemDetailID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_OM_Activity_ActivitySiteID] ON [dbo].[OM_Activity]
(
	[ActivitySiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_OM_Activity_ActivityType_ActivityItemID_ActivityNodeID_ActivityUTMSource_ActivityUTMContent_ActivityCampaign] ON [dbo].[OM_Activity]
(
	[ActivityType] ASC,
	[ActivityItemID] ASC,
	[ActivityNodeID] ASC
)
INCLUDE([ActivityUTMSource],[ActivityUTMContent],[ActivityCampaign]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[OM_Activity] ADD  CONSTRAINT [DEFAULT_OM_Activity_ActivityContactID]  DEFAULT ((0)) FOR [ActivityContactID]
GO
ALTER TABLE [dbo].[OM_Activity] ADD  CONSTRAINT [DEFAULT_OM_Activity_ActivitySiteID]  DEFAULT ((0)) FOR [ActivitySiteID]
GO
ALTER TABLE [dbo].[OM_Activity] ADD  CONSTRAINT [DEFAULT_OM_Activity_ActivityURLHash]  DEFAULT ((0)) FOR [ActivityURLHash]
GO
